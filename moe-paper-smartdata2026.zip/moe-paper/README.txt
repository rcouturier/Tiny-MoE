The Shared/Routed Split in Small Mixture-of-Experts Models
Is a Design Choice, Not a Diagnosis

Raphael Couturier, Stephane Cuenat
Universite Marie et Louis Pasteur, CNRS, Institut FEMTO-ST (UMR 6174), Belfort, France

Target venue : IEEE SmartData 2026 (Cybermatics congress, Montbeliard, 30 Nov - 4 Dec 2026)
Deadline     : 17 August 2026
Format       : IEEEtran conference, 8 pages including references, single-blind


CONTENTS
--------
paper_ieee.pdf        The compiled paper. Read this first.
paper_ieee.tex        Source (IEEEtran, conference option).
references.bib        21 entries, all cited.
figures/              The six PDF figures used by the paper, plus
                      make_figures.py which regenerates them from the
                      logged numbers (matplotlib only, no data files needed).
latex-class/          IEEEtran.cls and IEEEtran.bst, included so the paper
                      builds on a machine without texlive-publishers.
supporting/           Not part of the submission. The running results log and
                      the raw per-checkpoint run record behind every number in
                      the paper, for checking claims against the measurements.


BUILDING
--------
With IEEEtran already installed:

    pdflatex paper_ieee && bibtex paper_ieee && pdflatex paper_ieee && pdflatex paper_ieee

Without it, put the class and style where LaTeX will find them first:

    cp latex-class/IEEEtran.* .
    pdflatex paper_ieee && bibtex paper_ieee && pdflatex paper_ieee && pdflatex paper_ieee

The build should be silent: no undefined references, no undefined citations,
no overfull boxes above 20pt, and exactly 8 pages. If it comes out at 9, a
float has moved -- the paper sits exactly at the page limit and any edit can
push it over.


WHAT THE PAPER CLAIMS
---------------------
In small MoEs with an always-on shared expert, ablating the whole routed branch
costs little while ablating the shared expert costs a lot. The paper argues this
reflects optimization dynamics and architectural proportion, not what the
computation requires:

  - the imbalance is transient (branches equalize by ~300M tokens in the 134M
    reference model; a 16-layer model stays shared-dominated longer);
  - its cause is a gradient-exposure race, demonstrated causally by slowing the
    shared expert's learning rate, which reallocates computation at no
    perplexity cost;
  - a handicap over only the first tenth of training is enough, and the
    reallocation persists after it is lifted (dose-response over duration);
  - where the split lands is set jointly by the branches' relative width and by
    the routing granularity, not by the number of experts;
  - only the width lever reliably buys routed specialization; the learning-rate
    lever buys engagement without it.


POINTS A CO-AUTHOR MIGHT WANT TO CHECK
--------------------------------------
1. Table I (measurement validity). The headline statistic is a ratio of
   zero-ablation perplexity deltas; the table shows it survives mean-ablation
   and dissociates from the branch norm share. This answers the sharpest
   objection the draft received and is worth a second opinion.
2. The title. It was changed late: an earlier version claimed "Routed Experts
   Are Not Redundant", which conflated ablation-redundancy with functional
   redundancy while the results support the second. The introduction now
   separates the two senses explicitly.
3. Section VI-C restricts the width-ratio claim to fixed routing, because top-k
   turned out to matter more than any width manipulation. Two candidate
   single-scalar laws were tested and both refuted; the paper states a joint
   claim instead of fitting a law.
4. Limitations, in the Discussion rather than a separate section: 58M-436M
   parameters, at most 983M tokens, one data mixture, several single-seed
   points, no downstream benchmark (they sit near chance at this scale).

The reproducibility statement promises code, run configurations and
per-checkpoint measurements on acceptance. supporting/ already contains the
measurements.
